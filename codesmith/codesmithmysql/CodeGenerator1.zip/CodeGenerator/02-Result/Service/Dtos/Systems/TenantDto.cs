﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;
using Sand.Service;

namespace Sand.Service.Dtos.Systems {
    /// <summary>
    /// 租户数据传输对象
    /// </summary>
    [DataContract]
    public class TenantDto : DtoBase {
        /// <summary>
        /// 租户
        /// </summary>
        [Required(ErrorMessage = "租户不能为空")]
        [StringLength( 36, ErrorMessage = "租户输入过长，不能超过36位" )]
        [Display( Name = "租户" )]
        [DataMember]
        public string TenantId { get; set; }
        
        /// <summary>
        /// 租户名
        /// </summary>
        [Required(ErrorMessage = "租户名不能为空")]
        [StringLength( 80, ErrorMessage = "租户名输入过长，不能超过80位" )]
        [Display( Name = "租户名" )]
        [DataMember]
        public string TenantName { get; set; }
        
        /// <summary>
        /// 联系人
        /// </summary>
        [StringLength( 20, ErrorMessage = "联系人输入过长，不能超过20位" )]
        [Display( Name = "联系人" )]
        [DataMember]
        public string TelName { get; set; }
        
        /// <summary>
        /// 联系地址
        /// </summary>
        [StringLength( 80, ErrorMessage = "联系地址输入过长，不能超过80位" )]
        [Display( Name = "联系地址" )]
        [DataMember]
        public string Address { get; set; }
        
        /// <summary>
        /// 联系电话
        /// </summary>
        [Required(ErrorMessage = "联系电话不能为空")]
        [StringLength( 11, ErrorMessage = "联系电话输入过长，不能超过11位" )]
        [Display( Name = "联系电话" )]
        [DataMember]
        public string TelPhone { get; set; }
        
        /// <summary>
        /// 营业证书
        /// </summary>
        [StringLength( 36, ErrorMessage = "营业证书输入过长，不能超过36位" )]
        [Display( Name = "营业证书" )]
        [DataMember]
        public string BusinessCertificate { get; set; }
        
        /// <summary>
        /// 代码
        /// </summary>
        [StringLength( 36, ErrorMessage = "代码输入过长，不能超过36位" )]
        [Display( Name = "代码" )]
        [DataMember]
        public string Code { get; set; }
        
        /// <summary>
        /// 结束日期
        /// </summary>
        [Display( Name = "结束日期" )]
        [DataMember]
        public DateTime? EndTime { get; set; }
        
        /// <summary>
        /// 类型
        /// </summary>
        [Required(ErrorMessage = "类型不能为空")]
        [Display( Name = "类型" )]
        [DataMember]
        public int Type { get; set; }
        
        /// <summary>
        /// 状态
        /// </summary>
        [Required(ErrorMessage = "状态不能为空")]
        [Display( Name = "状态" )]
        [DataMember]
        public int Status { get; set; }
        
        /// <summary>
        /// 创建时间
        /// </summary>
        [Required(ErrorMessage = "创建时间不能为空")]
        [Display( Name = "创建时间" )]
        [DataMember]
        public DateTime CreateTime { get; set; }
        
        /// <summary>
        /// 创建者
        /// </summary>
        [Required(ErrorMessage = "创建者不能为空")]
        [StringLength( 36, ErrorMessage = "创建者输入过长，不能超过36位" )]
        [Display( Name = "创建者" )]
        [DataMember]
        public string CreateId { get; set; }
        
        /// <summary>
        /// 创建人
        /// </summary>
        [StringLength( 50, ErrorMessage = "创建人输入过长，不能超过50位" )]
        [Display( Name = "创建人" )]
        [DataMember]
        public string CreateName { get; set; }
        
        /// <summary>
        /// 最近更新时间
        /// </summary>
        [Display( Name = "最近更新时间" )]
        [DataMember]
        public DateTime? LastUpdateTime { get; set; }
        
        /// <summary>
        /// 最近更新者
        /// </summary>
        [StringLength( 36, ErrorMessage = "最近更新者输入过长，不能超过36位" )]
        [Display( Name = "最近更新者" )]
        [DataMember]
        public string LastUpdateId { get; set; }
        
        /// <summary>
        /// 最近更新人
        /// </summary>
        [StringLength( 50, ErrorMessage = "最近更新人输入过长，不能超过50位" )]
        [Display( Name = "最近更新人" )]
        [DataMember]
        public string LastUpdateName { get; set; }
        
        /// <summary>
        /// 版本号
        /// </summary>
        [Required(ErrorMessage = "版本号不能为空")]
        [Display( Name = "版本号" )]
        [DataMember]
        public Byte[] Version { get; set; }
        
        /// <summary>
        /// 删除标志
        /// </summary>
        [Required(ErrorMessage = "删除标志不能为空")]
        [Display( Name = "删除标志" )]
        [DataMember]
        public bool IsDeleted { get; set; }
        
        /// <summary>
        /// 
        /// </summary>
        [Required(ErrorMessage = "不能为空")]
        [Display( Name = "" )]
        [DataMember]
        public bool IsEnable { get; set; }
        
    }
}

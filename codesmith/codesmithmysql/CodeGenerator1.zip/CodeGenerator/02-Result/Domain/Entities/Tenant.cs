﻿namespace Sand.Domains.Systems.Models {
    /// <summary>
    /// 租户
    /// </summary>
    public partial class Tenant {
    }
}
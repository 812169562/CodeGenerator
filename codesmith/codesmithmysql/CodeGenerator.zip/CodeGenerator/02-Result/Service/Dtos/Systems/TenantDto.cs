﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace Sand.Service.Dtos.Systems {
    /// <summary>
    /// 租户数据传输对象
    /// </summary>
    [DataContract]
    public class TenantDto : DtoBase {
        /// <summary>
        /// 租户名
        /// </summary>
        [Required(ErrorMessage = "租户名不能为空")]
        [StringLength( 80, ErrorMessage = "租户名输入过长，不能超过80位" )]
        [Display( Name = "租户名" )]
        [DataMember]
        public string TenantName { get; set; }
        
        /// <summary>
        /// 联系人
        /// </summary>
        [StringLength( 20, ErrorMessage = "联系人输入过长，不能超过20位" )]
        [Display( Name = "联系人" )]
        [DataMember]
        public string TelName { get; set; }
        
        /// <summary>
        /// 联系地址
        /// </summary>
        [StringLength( 80, ErrorMessage = "联系地址输入过长，不能超过80位" )]
        [Display( Name = "联系地址" )]
        [DataMember]
        public string Address { get; set; }
        
        /// <summary>
        /// 联系电话
        /// </summary>
        [Required(ErrorMessage = "联系电话不能为空")]
        [StringLength( 11, ErrorMessage = "联系电话输入过长，不能超过11位" )]
        [Display( Name = "联系电话" )]
        [DataMember]
        public string TelPhone { get; set; }
        
        /// <summary>
        /// 营业证书
        /// </summary>
        [StringLength( 36, ErrorMessage = "营业证书输入过长，不能超过36位" )]
        [Display( Name = "营业证书" )]
        [DataMember]
        public string BusinessCertificate { get; set; }
        
        /// <summary>
        /// 代码
        /// </summary>
        [StringLength( 36, ErrorMessage = "代码输入过长，不能超过36位" )]
        [Display( Name = "代码" )]
        [DataMember]
        public string Code { get; set; }
        
        /// <summary>
        /// 结束日期
        /// </summary>
        [Display( Name = "结束日期" )]
        [DataMember]
        public DateTime? EndTime { get; set; }
        
        /// <summary>
        /// 类型
        /// </summary>
        [Required(ErrorMessage = "类型不能为空")]
        [Display( Name = "类型" )]
        [DataMember]
        public int Type { get; set; }
        
    }
}

﻿namespace Sand.Domains.Systems.Models {
    /// <summary>
    /// 字典表
    /// </summary>
    public partial class Dics {
    }
}
﻿using Sand.Domain.Repositories;
using Sand.Domain.Entities.Sittingtemplates;

namespace Sand.Domain.Repositories.Sittingtemplates {
    /// <summary>
    ///  坐诊模板仓储
    /// </summary>
    public interface ISittingtemplateRepository : IRepository<Sittingtemplate> {
    }
}

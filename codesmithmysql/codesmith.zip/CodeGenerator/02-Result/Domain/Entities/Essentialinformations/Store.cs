﻿namespace Sand.Domains.Essentialinformations.Models {
    /// <summary>
    /// 门店
    /// </summary>
    public partial class Store {
    }
}
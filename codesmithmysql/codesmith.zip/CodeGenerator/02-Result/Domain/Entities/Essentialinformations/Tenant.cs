﻿namespace Sand.Domains.Essentialinformations.Models {
    /// <summary>
    /// 医馆
    /// </summary>
    public partial class Tenant {
    }
}
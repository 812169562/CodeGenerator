﻿namespace Sand.Domains.Essentialinformations.Models {
    /// <summary>
    /// 租户用户多对多关系表
    /// </summary>
    public partial class Tenantuserrelation {
    }
}
﻿namespace Sand.Domains.Essentialinformations.Models {
    /// <summary>
    /// 部门信息
    /// </summary>
    public partial class Department {
    }
}
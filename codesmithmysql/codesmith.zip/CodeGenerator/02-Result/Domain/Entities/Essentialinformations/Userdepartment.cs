﻿namespace Sand.Domains.Essentialinformations.Models {
    /// <summary>
    /// 人员部门信息
    /// </summary>
    public partial class Userdepartment {
    }
}
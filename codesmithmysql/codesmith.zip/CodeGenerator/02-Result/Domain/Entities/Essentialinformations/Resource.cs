﻿namespace Sand.Domains.Essentialinformations.Models {
    /// <summary>
    /// 资源
    /// </summary>
    public partial class Resource {
    }
}
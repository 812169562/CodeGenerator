﻿namespace Sand.Domains.Essentialinformations.Models {
    /// <summary>
    /// 用户表
    /// </summary>
    public partial class Users {
    }
}
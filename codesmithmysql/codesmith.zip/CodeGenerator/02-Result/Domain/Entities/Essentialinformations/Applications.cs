﻿namespace Sand.Domains.Essentialinformations.Models {
    /// <summary>
    /// 应用程序
    /// </summary>
    public partial class Applications {
    }
}
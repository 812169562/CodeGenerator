﻿namespace Sand.Domains.Medicinestores.Models {
    /// <summary>
    /// 药品基本信息
    /// </summary>
    public partial class Drugs {
    }
}
﻿namespace Sand.Domains.Medicinestores.Models {
    /// <summary>
    /// 药品出入库
    /// </summary>
    public partial class Druginout {
    }
}
﻿namespace Sand.Domains.Medicinestores.Models {
    /// <summary>
    /// 药品批次信息
    /// </summary>
    public partial class Drugbatch {
    }
}
﻿namespace Sand.Domains.Medicinestores.Models {
    /// <summary>
    /// 药品调拨
    /// </summary>
    public partial class Drugallot {
    }
}
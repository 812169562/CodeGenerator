﻿namespace Sand.Domains.Medicinestores.Models {
    /// <summary>
    /// 调拨明细表
    /// </summary>
    public partial class Drugallotinfo {
    }
}
﻿namespace Sand.Domains.Medicinestores.Models {
    /// <summary>
    /// 库存(均以销售单位为库存量)
    /// </summary>
    public partial class Drugstock {
    }
}
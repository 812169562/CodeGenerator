﻿namespace Sand.Domains.Medicinestores.Models {
    /// <summary>
    /// 出入库明细表
    /// </summary>
    public partial class Druginoutinfo {
    }
}
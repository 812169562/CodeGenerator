﻿namespace Sand.Domains.Medicinestores.Models {
    /// <summary>
    /// 药品更新日志
    /// </summary>
    public partial class Drugupdatelog {
    }
}
﻿namespace Sand.Domains.Sittingtemplates.Models {
    /// <summary>
    ///  医生坐诊表
    /// </summary>
    public partial class Sitting {
    }
}
﻿namespace Sand.Domains.Sittingtemplates.Models {
    /// <summary>
    ///  坐诊模板
    /// </summary>
    public partial class Sittingtemplate {
    }
}
﻿namespace Sand.Domains.Materials.Models {
    /// <summary>
    ///  领用记录
    /// </summary>
    public partial class Accessrecord {
    }
}
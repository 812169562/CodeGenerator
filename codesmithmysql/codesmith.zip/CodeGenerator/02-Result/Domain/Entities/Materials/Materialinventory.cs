﻿namespace Sand.Domains.Materials.Models {
    /// <summary>
    /// 物资库存
    /// </summary>
    public partial class Materialinventory {
    }
}
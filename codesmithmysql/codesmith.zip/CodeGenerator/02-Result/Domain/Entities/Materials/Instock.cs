﻿namespace Sand.Domains.Materials.Models {
    /// <summary>
    /// 入库记录
    /// </summary>
    public partial class Instock {
    }
}
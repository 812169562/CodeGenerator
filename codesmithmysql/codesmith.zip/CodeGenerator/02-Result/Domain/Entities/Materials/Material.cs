﻿namespace Sand.Domains.Materials.Models {
    /// <summary>
    /// 物资
    /// </summary>
    public partial class Material {
    }
}
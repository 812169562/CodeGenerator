﻿namespace Sand.Domains.Orders.Models {
    /// <summary>
    /// 支付信息
    /// </summary>
    public partial class Paymentinformation {
    }
}
﻿namespace Sand.Domains.Orders.Models {
    /// <summary>
    /// 订单明细
    /// </summary>
    public partial class Prescriptionorderinfo {
    }
}
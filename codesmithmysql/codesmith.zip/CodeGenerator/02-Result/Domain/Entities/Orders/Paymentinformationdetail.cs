﻿namespace Sand.Domains.Orders.Models {
    /// <summary>
    ///  支付信息明细
    /// </summary>
    public partial class Paymentinformationdetail {
    }
}
﻿namespace Sand.Domains.Orders.Models {
    /// <summary>
    /// 订单处方
    /// </summary>
    public partial class Prescriptionorder {
    }
}
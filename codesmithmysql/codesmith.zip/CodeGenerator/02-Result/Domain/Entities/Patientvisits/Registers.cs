﻿namespace Sand.Domains.Patientvisits.Models {
    /// <summary>
    /// 挂号信息
    /// </summary>
    public partial class Registers {
    }
}
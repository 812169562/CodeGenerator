﻿namespace Sand.Domains.Patientvisits.Models {
    /// <summary>
    /// 预约挂号
    /// </summary>
    public partial class Appointmentregister {
    }
}
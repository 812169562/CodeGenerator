﻿namespace Sand.Domains.Patientvisits.Models {
    /// <summary>
    /// 就诊记录修改记录表
    /// </summary>
    public partial class Visitlog {
    }
}
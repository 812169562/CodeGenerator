﻿namespace Sand.Domains.Patientvisits.Models {
    /// <summary>
    /// 四诊信息
    /// </summary>
    public partial class Disease {
    }
}
﻿namespace Sand.Domains.Patientvisits.Models {
    /// <summary>
    /// 就诊信息
    /// </summary>
    public partial class Visit {
    }
}
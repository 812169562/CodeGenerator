﻿namespace Sand.Domains.Patientvisits.Models {
    /// <summary>
    /// 诊断信息
    /// </summary>
    public partial class Diagnosis {
    }
}
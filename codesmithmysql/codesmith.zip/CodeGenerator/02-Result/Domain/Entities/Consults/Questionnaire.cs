﻿namespace Sand.Domains.Consults.Models {
    /// <summary>
    /// 问卷表
    /// </summary>
    public partial class Questionnaire {
    }
}
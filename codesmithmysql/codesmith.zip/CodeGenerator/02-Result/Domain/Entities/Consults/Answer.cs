﻿namespace Sand.Domains.Consults.Models {
    /// <summary>
    /// 答案表
    /// </summary>
    public partial class Answer {
    }
}
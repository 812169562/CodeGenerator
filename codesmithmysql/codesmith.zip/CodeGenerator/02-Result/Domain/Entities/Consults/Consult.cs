﻿namespace Sand.Domains.Consults.Models {
    /// <summary>
    /// 咨询
    /// </summary>
    public partial class Consult {
    }
}
﻿namespace Sand.Domains.Consults.Models {
    /// <summary>
    /// 选项表
    /// </summary>
    public partial class Options {
    }
}
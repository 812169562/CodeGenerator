﻿namespace Sand.Domains.Activities.Models {
    /// <summary>
    /// 优惠卷消费记录
    /// </summary>
    public partial class Couponlog {
    }
}
﻿namespace Sand.Domains.Activities.Models {
    /// <summary>
    /// 优惠券
    /// </summary>
    public partial class Coupon {
    }
}
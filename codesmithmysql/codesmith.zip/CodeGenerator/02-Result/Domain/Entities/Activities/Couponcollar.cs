﻿namespace Sand.Domains.Activities.Models {
    /// <summary>
    /// 优惠券领用
    /// </summary>
    public partial class Couponcollar {
    }
}
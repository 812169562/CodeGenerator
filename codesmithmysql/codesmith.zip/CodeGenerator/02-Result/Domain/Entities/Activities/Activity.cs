﻿namespace Sand.Domains.Activities.Models {
    /// <summary>
    /// 优惠活动 
    /// </summary>
    public partial class Activity {
    }
}
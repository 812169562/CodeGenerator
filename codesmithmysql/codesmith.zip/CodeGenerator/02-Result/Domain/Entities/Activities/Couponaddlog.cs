﻿namespace Sand.Domains.Activities.Models {
    /// <summary>
    /// 优惠卷库存新增记录
    /// </summary>
    public partial class Couponaddlog {
    }
}
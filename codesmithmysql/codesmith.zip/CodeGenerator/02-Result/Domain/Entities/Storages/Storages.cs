﻿namespace Sand.Domains.Storages.Models {
    /// <summary>
    /// 存储
    /// </summary>
    public partial class Storages {
    }
}